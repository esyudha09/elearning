﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace AI_ERP.Application_Entities
{
    public class KedisiplinanSetup
    {
        public Guid Kode { get; set; }
        public string TahunAjaran { get; set; }
        public string Semester { get; set; }
        public string Rel_Sekolah { get; set; }
        public string Rel_Kelas { get; set; }
        public string Rel_Kedisiplinan_01 { get; set; }
        public string Rel_Kedisiplinan_02 { get; set; }
        public string Rel_Kedisiplinan_03 { get; set; }
        public string Rel_Kedisiplinan_04 { get; set; }
        public string Rel_Kedisiplinan_05 { get; set; }
        public string Rel_Kedisiplinan_06 { get; set; }
        public string Rel_Kedisiplinan_07 { get; set; }
        public string Rel_Kedisiplinan_08 { get; set; }
        public string Rel_Kedisiplinan_09 { get; set; }
        public string Rel_Kedisiplinan_10 { get; set; }

    }
}