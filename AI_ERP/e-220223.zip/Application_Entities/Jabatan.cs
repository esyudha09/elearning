﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace AI_ERP.Application_Entities
{
    public class Jabatan
    {
        public string Kode { set; get; }
        public string Nama { set; get; }
        public string Keterangan { set; get; }
    }
}