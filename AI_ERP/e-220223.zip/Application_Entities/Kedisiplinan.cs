﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace AI_ERP.Application_Entities
{
    public class Kedisiplinan
    {
        public Guid Kode { get; set; }
        public string Alias { get; set; }
        public string Keterangan { get; set; }
    }
}