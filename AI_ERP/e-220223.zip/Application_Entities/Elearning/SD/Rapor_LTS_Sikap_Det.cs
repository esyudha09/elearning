﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace AI_ERP.Application_Entities.Elearning.SD
{
    public class Rapor_LTS_Sikap_Det
    {
        public Guid Kode { get; set; }
        public Guid Rel_Rapor_LTS { get; set; }
        public string Rel_Siswa { get; set; }
        public string Rel_Mapel { get; set; }
        public string Rel_KD_Nilai1 { get; set; }
        public string Nilai1 { get; set; }
        public string Rel_KD_Nilai2 { get; set; }
        public string Nilai2 { get; set; }
        public string Rel_KD_Nilai3 { get; set; }
        public string Nilai3 { get; set; }
        public string Rel_KD_Nilai4 { get; set; }
        public string Nilai4 { get; set; }
        public string Rel_KD_Nilai5 { get; set; }
        public string Nilai5 { get; set; }
        public string Rel_KD_Nilai6 { get; set; }
        public string Nilai6 { get; set; }
        public string Rel_KD_Nilai7 { get; set; }
        public string Nilai7 { get; set; }
        public string Rel_KD_Nilai8 { get; set; }
        public string Nilai8 { get; set; }
        public string Rel_KD_Nilai9 { get; set; }
        public string Nilai9 { get; set; }
        public string Rel_KD_Nilai10 { get; set; }
        public string Nilai10 { get; set; }
    }
}