﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace AI_ERP.Application_Entities.Elearning.SD
{
    public class Rapor_LTS_Det
    {
        public Guid Kode { get; set; }
        public Guid Rel_Rapor_LTS { get; set; }
        public string Rel_Siswa { get; set; }
        public string Rel_Mapel { get; set; }
        public string Nilai1 { get; set; }
        public string Nilai2 { get; set; }
        public string Nilai3 { get; set; }
        public string Nilai4 { get; set; }
        public string Nilai5 { get; set; }
        public string Nilai6 { get; set; }
        public string Nilai7 { get; set; }
        public string Nilai8 { get; set; }
        public string Nilai9 { get; set; }
        public string Nilai10 { get; set; }
        public string Nilai11 { get; set; }
        public string Nilai12 { get; set; }
        public string Nilai13 { get; set; }
        public string Nilai14 { get; set; }
        public string Nilai15 { get; set; }
        public string Nilai16 { get; set; }
        public string Nilai17 { get; set; }
        public string Nilai18 { get; set; }
        public string Nilai19 { get; set; }
        public string Nilai20 { get; set; }
    }
}