﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace AI_ERP.Application_Entities.Elearning.SMP
{
    public class RaporLTSEkskul
    {
        public string Rel_Siswa { get; set; }
        public string Kegiatan { get; set; }
        public string LTS_CK_KEHADIRAN { get; set; }
        public int Urutan { get; set; }
    }
}