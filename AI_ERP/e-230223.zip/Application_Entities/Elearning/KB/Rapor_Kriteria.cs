﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace AI_ERP.Application_Entities.Elearning.KB
{
    public class Rapor_Kriteria
    {
        public Guid Kode { get; set; }
        public string Alias { get; set; }
        public string Nama { get; set; }
        public string Keterangan { get; set; }
    }
}