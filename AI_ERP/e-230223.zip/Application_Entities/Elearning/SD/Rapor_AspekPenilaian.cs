﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace AI_ERP.Application_Entities.Elearning.SD
{
    public class Rapor_AspekPenilaian
    {
        public Guid Kode { get; set; }
        public string Nama { get; set; }
        public string Alias { get; set; }
        public string Keterangan { get; set; }
    }
}