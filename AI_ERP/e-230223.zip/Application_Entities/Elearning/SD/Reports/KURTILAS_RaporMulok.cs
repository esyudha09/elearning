﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace AI_ERP.Application_Entities.Elearning.SD.Reports
{
    public class KURTILAS_RaporMulok
    {
        public string IDSiswa { get; set; }
        public string NamaMapel { get; set; }
        public string Nilai { get; set; }
        public string Predikat { get; set; }
        public string NilaiRataRataSM1SM2 { get; set; }
        public string PredikatRataRataSM1SM2 { get; set; }
    }
}