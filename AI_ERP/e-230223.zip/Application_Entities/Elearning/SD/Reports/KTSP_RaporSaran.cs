﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace AI_ERP.Application_Entities.Elearning.SD.Reports
{
    public class KTSP_RaporSaran
    {
        public string IDSiswa { get; set; }
        public string Saran { get; set; }
    }
}