﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace AI_ERP.Application_Entities.Elearning.SMP.Reports
{
    public class KTSP_RaporKetidakhadiran
    {
        public string IDSiswa { get; set; }
        public string Sakit { get; set; }
        public string Izin { get; set; }
        public string Alpa { get; set; }
        public string Kelakuan { get; set; }
        public string Kerajinan { get; set; }
        public string Kerapihan { get; set; }
    }
}