﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace AI_ERP.Application_Entities.Elearning.SMP
{
    public class Rapor_KomponenPenilaian
    {
        public Guid Kode { get; set; }
        public string Nama { get; set; }
        public string Alias { get; set; }
        public string Keterangan { get; set; }
    }
}