﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace AI_ERP.Application_DAOs.Elearning.SD
{
    public class DAO_Rapor_StrukturNilai_KD_MapelInput
    {
    }
}