﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.Common;
using System.Data.SqlClient;

using AI_ERP.Application_Entities;

namespace AI_ERP.Application_DAOs
{
    public static class DAO_CBT_RumahSoalSMA
    {
        
       
        public const string SP_SMA_Rapor_StrukturNilai_SELECT_ALL_BY_TA_BY_MAPEL = "SMA_Rapor_StrukturNilai_SELECT_ALL_BY_TA_BY_MAPEL";
        public const string SP_SMA_Rapor_StrukturNilai_SELECT_ALL_BY_TA_BY_MAPEL_FOR_SEARCH = "SMA_Rapor_StrukturNilai_SELECT_ALL_BY_TA_BY_MAPEL_FOR_SEARCH";
        
     





    }
}